package com.green.security_exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityExamApplication.class, args);
	}

}
