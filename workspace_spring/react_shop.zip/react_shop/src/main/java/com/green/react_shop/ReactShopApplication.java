package com.green.react_shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactShopApplication.class, args);
	}

}
